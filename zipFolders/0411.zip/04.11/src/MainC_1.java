import java.util.Arrays;
import java.util.Scanner;

public class MainC_1 {

	public static void main(String[] args) {
		MainC_2[] name = {new MainC_2("A"), new MainC_2("B"), new MainC_2("C")};
		MainC_3[] mains = new MainC_3[name.length];
		for(int i = 0; i < name.length; i++) {
			mains[i] = new MainC_3();
		}
		Scanner scanner = new Scanner(System.in);
		System.out.println("몇 반을 선택할까요?");
		System.out.println("A반 | B반 | C반");
		String userInput = scanner.nextLine();
		if(userInput.equals(name[0].className)) {
			mains[0].main();
		}
		else if(userInput.equals(name[1].className)) {
			mains[1].main();
		}
		else if(userInput.equals(name[2].className)) {
			mains[2].main();
		}
		else {
			System.out.println("올바른 학급 인덱스를 입력해주세요.");
		}
	}
}