
public class Main_Lecture_02 {
	String name = "";
	int mid_kor = 0;
	int mid_eng = 0;
	int mid_math = 0;
	int last_kor = 0;
	int last_eng = 0;
	int last_math = 0;
	String region = "";
	String gender = "";
	
	
	
	
	
	
	
	
	public void classCount() {
		int sum_mid_kor = 0, sum_mid_eng = 0, sum_mid_math = 0, sum_last_kor = 0, sum_last_eng = 0, sum_last_math = 0;
		for(test = 0; test < 2) {
			for(study = 0; study < 3) {
				if(test == 0 && study == 0) {
					sum_mid_kor = sum_mid_kor + this.mid_kor;
				}
				else if(test == 0 && study == 1) {
					sum_mid_eng = sum_mid_eng + this.mid_kor;
				}
				else if(test == 0 && study == 2) {
					sum_mid_math = sum_mid_math + this.mid_math;
				}
				else if(test == 1 && study == 0) {
					sum_last_kor = sum_last_kor + this.last_kor;
					
				}	else if(test == 1 && study == 0) {
					sum_last_kor = sum_last_kor + this.last_kor;
				}	else if(test == 1 && study == 1) {
					sum_last_eng = sum_last_eng + this.last_eng;
				}	else if(test == 1 && study == 2) {
					sum_last_eng = sum_last_eng + this.last_eng;
				}		
			}
		}
		System.out.println("중간고사 학급 국어 총점 :" + sum_mid_kor);
		System.out.println("중간고사 학급 영어 총점 :" + sum_mid_eng);
		System.out.println("중간고사 학급 수학 총점 :" + sum_mid_math);
		System.out.println("기말고사 학급 국어 총점 :" + sum_last_kor);
		System.out.println("기말고사 학급 영어 총점 :" + sum_last_eng);
		System.out.println("기말고사 학급 국어 총점 :" + sum_last_math);
	}
	public void totalprint() {
		for(int i = 0; i < numCount; i++) {
			System.out.println("이름 : "+ this.name + " 주소 : " + this.region + " 성별 : " + this.gender);
			System.out.println("중간 국어 성적 : " + this.mid_kor + "중간 영어 성적 : " + this.mid_eng + " 중간 수학 성적 : " + this.mid_math);
			System.out.println("기말 국어 성적 : " + this.last_kor + "기말 영어 성적 : " + this.last_eng + " 기말 수학 성적 : " + this.last_math);
		}
	}