import java.util.Scanner;

public class MainC_4 {

	String name = "";
	int mid_kor = 0;
	int mid_eng = 0;
	int mid_math = 0;
	int last_kor = 0;
	int last_eng = 0;
	int last_math = 0;
	String region = "";
	String gender = "";

	public void nameInput() {
		System.out.println("이름을 입력해주세요.");
		Scanner scanner = new Scanner(System.in);
		this.name = scanner.nextLine();
	}

	public void mid_test_Input() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("중간고사 국어 성적을 입력해주세요.");
		this.mid_kor = Integer.parseInt(scanner.nextLine());
		System.out.println("중간고사 영어 성적을 입력해주세요.");
		this.mid_eng = Integer.parseInt(scanner.nextLine());
		System.out.println("중간고사 수학 성적을 입력해주세요.");
		this.mid_math = Integer.parseInt(scanner.nextLine());
		System.out.println();
	}

	public void last_test_Input() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("기말고사 국어 성적을 입력해주세요.");
		this.last_kor = Integer.parseInt(scanner.nextLine());
		System.out.println("기말고사 영어 성적을 입력해주세요.");
		this.last_eng = Integer.parseInt(scanner.nextLine());
		System.out.println("기말고사 수학 성적을 입력해주세요.");
		this.last_math = Integer.parseInt(scanner.nextLine());
		System.out.println();
	}

	public void regionInput() {
		System.out.println("거주 지역 정보를 입력해주세요.");
		Scanner scanner = new Scanner(System.in);
		this.region = scanner.nextLine();
	}

	public void genderInput() {
		System.out.println("성별을 입력해주세요");
		System.out.println("남/여");
		Scanner scanner = new Scanner(System.in);
		this.gender = scanner.nextLine();
	}

}
