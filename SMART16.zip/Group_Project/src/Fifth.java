
public class Fifth extends Base{
	String name;
	Fifth(){
		this.name = "FIFTH";
	}
}
