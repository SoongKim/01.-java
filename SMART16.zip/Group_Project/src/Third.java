
public class Third extends Base{
	String name;
	Third(){
		this.name = "Third";
	}
}
