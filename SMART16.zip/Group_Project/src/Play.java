
public class Play {

	public int apponentRoll() {
		DiceModule dm = new DiceModule();
		return dm.diceTwenty();
	}

}
