
public class Fourth extends Base{
	String name;
	Fourth(){
		this.name = "FOURTH";
	}
}
