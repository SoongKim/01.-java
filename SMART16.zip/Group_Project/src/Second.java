
public class Second extends Base{
	String name;
	Second(){
		this.name = "Second";
	}
}
